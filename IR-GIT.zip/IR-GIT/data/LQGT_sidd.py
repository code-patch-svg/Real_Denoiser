import os
import random
import sys
import cv2
import numpy as np
import torch
import torch.utils.data as data
import util


class LQGTDataset(data.Dataset):
    def __init__(self, args,num_of_crops=4,crop_sz=(256,256)):
        super().__init__()
        self.args = args
        self.crop_w,self.crop_h = crop_sz
        self.LR_paths, self.GT_paths = None, None
        self.num_crops = num_of_crops
        self.GT_paths, self.GT_sizes = util.get_image_paths(args["dataroot_GT"])
        self.LR_paths, self.LR_sizes = util.get_image_paths(args["dataroot_LR"])
        assert self.GT_paths, "Error: GT paths are empty."

    def __getitem__(self, index):

        GT_path, LR_path = None, None
        GT_path = self.GT_paths[index]
        img_GT = util.read_img(
             GT_path
        )  # return: Numpy float32, HWC, BGR, [0,1]

        # get LR image
        if self.LR_paths:  # LR exist
            LR_path = self.LR_paths[index]
            img_LR = util.read_img( LR_path)
            H, W, _ = img_GT.shape
            if img_LR.ndim == 2:
                img_LR = np.expand_dims(img_LR, axis=2)

        if self.args["phase"] == "train":

            #random cropping
            H, W, C = img_LR.shape
            in_crops = []
            gt_crops = []
            # randomly crop
            for _ in range(self.num_crops):
                rnd_h = random.randint(0, max(0, H -self.crop_h))
                rnd_w = random.randint(0, max(0, W - self.crop_w))

                img_LR = img_LR[rnd_h : rnd_h + self.crop_h, rnd_w : rnd_w + self.crop_w, :]
                img_GT = img_GT[rnd_h : rnd_h + self.crop_h, rnd_w : rnd_w + self.crop_w, :]
                # augmentation - flip, rotate
                img_LR, img_GT = util.augment(
                    img_LR, img_GT,
                    self.args["use_flip"],
                    self.args["use_rot"],
                    self.args["mode"],
                    self.args["use_swap"],
                )
                if img_GT.shape[3] == 3:
                    img_GT = img_GT[:, :, [2, 1, 0]] #BGR -  RGB
                    img_LR = img_LR[:, :, [2, 1, 0]]
                img_GT = torch.from_numpy(
                    np.ascontiguousarray(np.transpose(img_GT, (2, 0, 1)))
                ).float()
                img_LR = torch.from_numpy(
                    np.ascontiguousarray(np.transpose(img_LR, (2, 0, 1)))
                ).float()
                in_crops.append(img_LR)
                gt_crops.append(img_GT)

            #strack up the num_of_crops into single batch
            img_GT = torch.stack(gt_crops)  #[num_crops,H , W , C]
            img_LR = torch.stack(in_crops)  #[num_crops,H , W , C]

        # BGR to RGB, HWC to CHW, numpy to tensor


        return {"LQ": img_LR, "GT": img_GT, "LQ_path": LR_path, "GT_path": GT_path}

    def __len__(self):
        return len(self.GT_paths)
ßß