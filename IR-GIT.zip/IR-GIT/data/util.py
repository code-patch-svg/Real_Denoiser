import math
import os
import pickle
import random

import cv2
import numpy as np
import torch

IMG_EXTENSIONS = ['.jpg', '.JPG', '.jpeg', '.JPEG', '.png', '.PNG',]

def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)

def get_image_paths(path):
    '''get image path list from image folder'''
    assert os.path.isdir(path), '{:s} is not a valid directory'.format(path)
    images = []
    for dirpath, _, fnames in sorted(os.walk(path)):
        for fname in sorted(fnames):
            if is_image_file(fname):
                img_path = os.path.join(dirpath, fname)
                images.append(img_path)
    assert images, '{:s} has no valid image file'.format(path)
    return images


def read_img(path):
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    # some images have 4 channels
    if img.shape[2] > 3:
        img = img[:, :, :3]
    return img

def augment(
    low_res_image,
    high_res_image,
    flip_horizontal=True,
    rotate=True,
    transform_mode=None,
    allow_swap=None
):

    # random flipping
    apply_hflip = flip_horizontal and (random.random() < 0.5)
    apply_vflip = rotate and (random.random() < 0.5)
    apply_rot90 = rotate and (random.random() < 0.5)

    def _transform_single(img):
        if apply_hflip:
            img = img[:, ::-1, :]
        if apply_vflip:
            img = img[::-1, :, :]
        if apply_rot90:
            img = img.transpose(1, 0, 2)
        return img

    # Depending on the mode, transform a single image or a list of images
    if transform_mode in ['LQ', 'GT', 'SRker']:
        return _transform_single(img=low_res_image)
    elif transform_mode in ['LQGTker', 'LQGT']:
        if allow_swap and (random.random() < 0.5):
            high_res_image.reverse()
        return [_transform_single(img) for img in high_res_image]