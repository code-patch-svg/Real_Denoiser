import logging
from collections import OrderedDict
import os
import numpy as np
import math
import torch
import torch.nn as nn
from torch.nn.parallel import DataParallel, DistributedDataParallel
import torchvision.utils as tvutils
from tqdm import tqdm
import models.lr_scheduler as lr_scheduler
import models.networks as networks
from models.optimizer import Lion
from models.modules.loss import pixel_loss

logger = logging.getLogger("base")


class LatentModel(nn.Module):
    def __init__(self, args):
        super().__init__(args)

        if args["dist"]:
            self.rank = torch.distributed.get_rank()
        else:
            self.rank = -1  # non dist training
        train_args = args["train"]

        # define network and load pretrained models
        self.model = networks.define_G(args).to(self.device)
        if args["dist"]:
            self.model = DistributedDataParallel(
                self.model, device_ids=[torch.cuda.current_device()]
            )
        # else:
        #     self.model = DataParallel(self.model)
        # print network
        # self.print_network()
        self.load()

        if self.is_train:
            self.model.train()

            is_weighted = args['train']['is_weighted']
            loss_type = args['train']['loss_type']
            self.loss_fn = pixel_loss(loss_type, is_weighted).to(self.device)

            self.weight = args['train']['weight']

            # optimizers
            wd_G = train_args["weight_decay_G"] if train_args["weight_decay_G"] else 0
            argsim_params = []
            for (
                k,
                v,
            ) in self.model.named_parameters():  # can optimize for a part of the model
                if v.requires_grad:
                    argsim_params.append(v)
                else:
                    if self.rank <= 0:
                        logger.warning("Params [{:s}] will not optimize.".format(k))

            self.optimizer = Lion(
                    argsim_params,
                    lr=train_args["lr_G"],
                    weight_decay=wd_G,
                    betas=(train_args["beta1"], train_args["beta2"]),
                )
            self.optimizers.append(self.optimizer)

            # schedulers
            if train_args["lr_scheme"] == "CosineAnnealingLR_Restart":
                for optimizer in self.optimizers:
                    self.schedulers.append(
                        lr_scheduler.CosineAnnealingLR_Restart(
                            optimizer,
                            train_args["T_period"],
                            eta_min=train_args["eta_min"],
                            restarts=train_args["restarts"],
                            weights=train_args["restart_weights"],
                        )
                    )
            elif train_args["lr_scheme"] == "TrueCosineAnnealingLR":
                for optimizer in self.optimizers:
                    self.schedulers.append(
                        torch.argsim.lr_scheduler.CosineAnnealingLR(
                            optimizer,
                            T_max=train_args["niter"],
                            eta_min=train_args["eta_min"])
                    )
            else:
                raise NotImplementedError("MultiStepLR learning rate scheme is enough.")

            # self.ema = EMA(self.model, beta=0.995, update_every=10).to(self.device)
            self.log_dict = OrderedDict()

    def feed_data(self, LQ, GT=None):
        self.LQ = LQ.to(self.device)  # LQ
        self.GT = GT.to(self.device) if GT is not None else None

    def optimize_parameters(self, step):
        self.optimizer.zero_grad()

        if self.args["dist"]:
            encode_fn = self.model.module.encode
            decode_fn = self.model.module.decode
        else:
            encode_fn = self.model.encode
            decode_fn = self.model.decode

        L_lq, H_lq = encode_fn(self.LQ)
        L_gt, H_gt = encode_fn(self.GT)

        rec_llq_hlq = decode_fn(L_lq, H_lq) # latent LQ, Feature maps LQ
        rec_lgt_hlq = decode_fn(L_gt, H_lq) # latent GT, Feature maps LQ

        loss_rec = self.loss_fn(rec_llq_hlq, self.LQ) #+ self.loss_fn(rec_lgt_hgt, self.GT)
        loss_rep = self.loss_fn(rec_lgt_hlq, self.GT) #+ self.loss_fn(rec_llq_hgt, self.LQ)

        # loss_reg = torch.mean(L_lq**2) + torch.mean(L_gt**2)
        loss_reg = (L_lq.mean()-self.LQ.mean()).abs() + (L_lq.std() - self.LQ.std()*0.5).abs()

        loss = loss_rec + loss_rep + loss_reg * 0.001
        loss.backward()
        self.optimizer.step()

    def test(self):
        self.model.eval()

        if self.args["dist"]:
            encode_fn = self.model.module.encode
            decode_fn = self.model.module.decode
        else:
            encode_fn = self.model.encode
            decode_fn = self.model.decode

        with torch.no_grad():
            L_lq, H_lq = encode_fn(self.LQ)  #Latent Encoder
            L_gt, H_gt = encode_fn(self.GT)  #Latent Decoder

            self.real_lq = decode_fn(L_lq, H_lq) # latent LQ, Feature maps LQ
            self.fake_gt = decode_fn(L_gt, H_lq) # latent GT, Feature maps LQ

            self.fake_lq = decode_fn(L_lq, H_gt) # latent LQ, Feature maps GT
            self.real_gt = decode_fn(L_gt, H_gt) # latent GT, Feature maps GT

        self.model.train()

    def get_current_log(self):
        return self.log_dict

    def get_current_visuals(self, need_GT=True):
        out_dict = OrderedDict()
        out_dict["Input"] = self.LQ.detach()[0].float().cpu()
        out_dict["Output"] = self.fake_gt.detach()[0].float().cpu()
        if need_GT:
            out_dict["GT"] = self.GT.detach()[0].float().cpu()
        return out_dict

    def print_network(self):
        s, n = self.get_network_description(self.model)
        if isinstance(self.model, nn.DataParallel) or isinstance(
            self.model, DistributedDataParallel
        ):
            net_struc_str = "{} - {}".format(
                self.model.__class__.__name__, self.model.module.__class__.__name__
            )
        else:
            net_struc_str = "{}".format(self.model.__class__.__name__)
        if self.rank <= 0:
            logger.info(
                "Network G structure: {}, with parameters: {:,d}".format(
                    net_struc_str, n
                )
            )
            logger.info(s)

    def load(self):
        load_path_G = self.args["path"]["pretrain_model_G"]
        if load_path_G is not None:
            logger.info("Loading model for G [{:s}] ...".format(load_path_G))
            self.load_network(load_path_G, self.model, self.args["path"]["strict_load"])

    def save(self, iter_label):
        self.save_network(self.model, "G", iter_label)

